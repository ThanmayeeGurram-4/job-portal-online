package com.stackroute.jobservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
