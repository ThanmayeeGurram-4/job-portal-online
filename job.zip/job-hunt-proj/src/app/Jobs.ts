export class Jobs{
    name:string
    role:string
    location:string
    company:string
    id:string
    landing_page:string
}