export class UserHelper {
    userName:string;
    oldPassword:string;
    newPassword:string;
    
}
